#include <iostream>
#include <SFML/Graphics.hpp>

int main() {
	sf::RenderWindow window(sf::VideoMode(800, 600), "Bounce");
	window.setFramerateLimit(60);

	sf::CircleShape circulo(50);

	sf::Vector2f pos(400.0f, 100.0f);
	sf::Vector2f velocidad(0.0f, 500.0f);

	const float aceleracion = 5.0f;

	while (window.isOpen()) {
		sf::Event evt;

		while (window.pollEvent(evt)) {
			if (evt.type == sf::Event::Closed)
				window.close();
		}

		float deltaT = 1.0f / 60.0f;

		velocidad.y += aceleracion + deltaT;

		pos += velocidad * deltaT;

		if (velocidad.y > 0.0f && pos.y > 500.0f) {
			pos.y = 500;
			velocidad.y = -velocidad.y * 0.75;
		}

		window.clear();
		circulo.setPosition(pos);
		circulo.setFillColor(sf::Color::White);
		window.draw(circulo);
		window.display();
	}

	return 0;
}