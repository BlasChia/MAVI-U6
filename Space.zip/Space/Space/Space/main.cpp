#include <iostream>
#include <SFML/Graphics.hpp>

int main() {

	sf::RenderWindow window(sf::VideoMode(800, 600), "Space");
	window.setFramerateLimit(60);
	
	sf::CircleShape circulo(50);
	circulo.setOrigin(circulo.getRadius(), circulo.getRadius());
	circulo.setPosition(400, 300);
	circulo.setFillColor(sf::Color::White);

	sf::Clock reloj;
	
	float velocidadActual = 0, aceleracion = 0;

	while (window.isOpen()) {
		sf::Event evento;

		while (window.pollEvent(evento)) {
			
			if (evento.type == sf::Event::Closed)
				window.close();
			if (evento.type == sf::Event::KeyPressed) {
				if (evento.key.code == sf::Keyboard::Left) {
					aceleracion = -5;
				}
				if (evento.key.code == sf::Keyboard::Right) {
					aceleracion = 5;
				}
			}
			if (evento.type == sf::Event::KeyReleased) {
				aceleracion = 0;
			}
		}

		float tiempo = reloj.restart().asSeconds();

		velocidadActual += aceleracion + tiempo;
		circulo.move(velocidadActual * tiempo, 0);

		if (circulo.getPosition().x + circulo.getRadius() >= 900) {
			circulo.setPosition(400, 300);
			velocidadActual = velocidadActual * 0.5;
		}

		if (circulo.getPosition().x + circulo.getRadius() < 0) {
			circulo.setPosition(400, 300);
			velocidadActual = velocidadActual * 0.5;
		}

		window.clear();
		window.draw(circulo);
		window.display();
	}

	return 0;
}